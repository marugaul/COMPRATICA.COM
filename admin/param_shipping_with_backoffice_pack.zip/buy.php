<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/notify.php';
require_once __DIR__ . '/includes/shipping.php';

$pdo = db();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $error = 'Solicitud inválida.'; }

if (empty($error)) {
    $product_id = (int)($_POST['product_id'] ?? 0);
    $qty        = max(1, (int)($_POST['qty'] ?? 1));
    $email      = trim($_POST['buyer_email'] ?? '');
    $phone      = trim($_POST['buyer_phone'] ?? '');
    $residency  = trim($_POST['residency'] ?? 'Otro');
    $shipping   = ($_POST['shipping'] ?? 'pickup') === 'delivery' ? 'delivery' : 'pickup';
    $note_input = trim($_POST['note'] ?? '');

    // Producto
    $st = $pdo->prepare("SELECT * FROM products WHERE id=? AND active=1");
    $st->execute([$product_id]);
    $p = $st->fetch(PDO::FETCH_ASSOC);

    if (!$p)                              $error = 'Producto no encontrado.';
    if (empty($email) || empty($phone))   $error = 'Correo y teléfono son requeridos.';
    if ($p && (int)$p['stock'] < $qty)    $error = 'No hay suficiente inventario.';

    if (empty($error)) {
        $exrate   = (float) get_exchange_rate(); if ($exrate <= 0) $exrate = 1; // CRC por USD
        $price    = (float) $p['price'];
        $is_usd   = (($p['currency'] ?? 'CRC') === 'USD');

        $subtotal_crc = $is_usd ? ($price * $qty * $exrate) : ($price * $qty);
        $shipping_crc = ($shipping === 'delivery') ? get_shipping_cost() : 0;
        $total_crc    = $subtotal_crc + $shipping_crc;

        $subtotal_usd = $subtotal_crc / $exrate;
        $shipping_usd = $shipping_crc / $exrate;
        $total_usd    = $subtotal_usd + $shipping_usd;

        $shipping_text = ($shipping === 'delivery')
          ? ('Entrega ₡' . number_format(get_shipping_cost(), 0, ',', '.'))
          : 'Recogerlo';
        $note = trim($note_input . (strlen($note_input)?' | ':'') . 'Envío: ' . $shipping_text);

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO orders (product_id, qty, buyer_email, buyer_phone, residency, note, created_at, status)
                                   VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$product_id,$qty,$email,$phone,$residency,$note,now_iso(),'Pendiente']);
            $order_id = $pdo->lastInsertId();

            $pdo->prepare("UPDATE products SET stock=stock-?, updated_at=? WHERE id=?")
                ->execute([$qty, now_iso(), $product_id]);

            $pdo->prepare("UPDATE orders SET exrate_used=? WHERE id=?")->execute([$exrate, $order_id]);

            $pdo->commit();
            $ok = true;
        } catch(Exception $e) {
            $pdo->rollBack();
            $error = 'Error al procesar la compra.';
        }
    }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Confirmación - <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="assets/style.css?v=16">
</head>
<body>
<header class="header">
  <div class="logo">🛒 <?php echo APP_NAME; ?></div>
  <nav><a class="btn" href="index.php">Volver</a></nav>
</header>

<div class="container">
<?php if (!empty($ok)): ?>
  <div class="success">
    <h2>¡Pedido #<?php echo (int)$order_id; ?> creado!</h2>
    <p>Te contactaremos al <strong><?php echo htmlspecialchars($phone); ?></strong> o <strong><?php echo htmlspecialchars($email); ?></strong>.</p>
    <p class="small">Residencia: <?php echo htmlspecialchars($residency); ?> — Envío: <?php echo htmlspecialchars($shipping_text); ?></p>
  </div>

  <div class="card" style="margin-top:12px">
    <h3>Resumen</h3>
    <table class="table">
      <tr><td>Subtotal</td><td style="text-align:right">₡<?= number_format($subtotal_crc, 0, ',', '.') ?></td></tr>
      <tr><td>Envío</td><td style="text-align:right">₡<?= number_format($shipping_crc, 0, ',', '.') ?></td></tr>
      <tr><td style="font-weight:700">Total</td><td style="text-align:right;font-weight:700">₡<?= number_format($total_crc, 0, ',', '.') ?></td></tr>
    </table>
  </div>

  <div class="card" style="margin-top:16px; text-align:center;">
    <h3>Opciones de pago</h3>
    <?php
      // SINPE Móvil (sin QR) + subir comprobante
      echo '<div style="margin-bottom:18px">';
      echo   '<img src="assets/sinpe.png" alt="SINPE Móvil" style="max-width:220px;height:auto;margin:10px auto;display:block;">';
      echo   '<div class="small">Paga por <strong>SINPE Móvil</strong> al número <strong>'.htmlspecialchars(SINPE_PHONE).'</strong></div>';
      echo   '<div class="small" style="margin-bottom:8px">Total a pagar: <strong>₡'.number_format($total_crc,0,',','.').'</strong></div>';
      echo   '<form class="form" method="post" action="upload_proof.php" enctype="multipart/form-data">';
      echo     '<input type="hidden" name="order_id" value="'.(int)$order_id.'">';
      echo     '<label>Comprobante (foto o PDF)<input class="input" type="file" name="proof" accept="image/*,application/pdf" required></label>';
      echo     '<button class="btn" type="submit" style="display:inline-flex;align-items:center;gap:8px;"><span>📤 Subir comprobante</span></button>';
      echo   '</form>';
      echo '</div>';

      // PayPal (USD)
      $item        = urlencode(APP_NAME . ' - ' . $p['name']);
      $amount_usd  = number_format($total_usd, 2, '.', '');
      $paypal_link = "https://www.paypal.com/cgi-bin/webscr?cmd=_xclick"
        . "&business="      . urlencode(PAYPAL_EMAIL)
        . "&item_name="     . $item
        . "&amount="        . $amount_usd
        . "&currency_code=USD"
        . "&notify_url="    . urlencode(app_base_url() . "/paypal_ipn.php")
        . "&return="        . urlencode(app_base_url() . "/gracias.php")
        . "&cancel_return=" . urlencode(app_base_url() . "/cancelado.php")
        . "&custom="        . urlencode($order_id)
        . "&rm=2";
      echo '<div>';
      echo   '<a href="'.$paypal_link.'" '
             .'style="display:inline-flex;align-items:center;gap:10px;padding:12px 18px;'
                    .'border-radius:10px;background:#003087;color:#fff;'
                    .'text-decoration:none;font-weight:700;box-shadow:0 1px 2px rgba(0,0,0,.08);">'
             .'<img src="assets/paypal.png?v=2" alt="PayPal" '
                    .'style="display:block;height:20px;width:auto;filter:brightness(0) invert(1);object-fit:contain;">'
             .'<span>Pagar con PayPal</span>'
             .'</a>';
      echo   '<div class="small" style="margin-top:6px">Monto PayPal: $'.number_format((float)$amount_usd,2,'.',',').' (TC: '.$exrate.')</div>';
      echo '</div>';
    ?>
  </div>

<?php else: ?>
  <div class="alert"><strong>Error:</strong> <?php echo htmlspecialchars($error ?? ''); ?></div>
<?php endif; ?>
</div>

<footer class="container small">© <?php echo date('Y'); ?> <?php echo APP_NAME; ?></footer>
</body>
</html>