<?php
// Página independiente en Admin para editar costo de envío (CRC).
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/shipping.php';
require_once __DIR__ . '/auth.php'; // asegura sesión admin si la tienes

$pdo = db();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_shipping_cost'])) {
  $val = (int)($_POST['shipping_cost_crc'] ?? 2000);
  if ($val < 0) $val = 0;
  $pdo->exec("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)");
  $pdo->prepare("INSERT OR REPLACE INTO settings (k,v) VALUES ('shipping_cost_crc', ?)")->execute([(string)$val]);
  $msg = "Costo de envío actualizado a ₡" . number_format($val, 0, ',', '.');
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Config. Envío - <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="../assets/style.css?v=16">
</head>
<body>
<header class="header">
  <div class="logo">🛒 Admin — <?php echo APP_NAME; ?></div>
  <nav>
    <a class="btn" href="dashboard.php">Dashboard</a>
    <a class="btn" href="../index.php">Tienda</a>
  </nav>
</header>

<div class="container">
  <?php if ($msg): ?>
    <div class="success"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <div class="card">
    <h3>Configuración de envío</h3>
    <form method="post" class="form" style="max-width:380px">
      <label>Costo de envío (CRC)
        <input class="input" type="number" name="shipping_cost_crc"
               value="<?= htmlspecialchars((string)get_shipping_cost()) ?>" min="0" step="1" required>
      </label>
      <button class="btn primary" name="save_shipping_cost" value="1">Guardar</button>
    </form>
    <p class="small">Este costo se aplica cuando el cliente elige <strong>Entrega</strong> en el checkout.</p>
  </div>
</div>

</body>
</html>
