<?php
// Utilidad rápida para establecer el costo de envío por única vez.
// 1) Suba este archivo a /tools/
// 2) Abra en el navegador: https://TU_DOMINIO/tools/set_shipping_cost_once.php?v=2500
// 3) Verá "OK". Luego BORRE este archivo por seguridad.
require_once __DIR__ . '/../includes/db.php';
$pdo = db();
$pdo->exec("CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT)");
$val = isset($_GET['v']) ? (int)$_GET['v'] : 2000;
if ($val < 0) $val = 0;
$st = $pdo->prepare("INSERT OR REPLACE INTO settings (k,v) VALUES ('shipping_cost_crc', ?)");
$st->execute([(string)$val]);
echo "OK: shipping_cost_crc = " . $val;
