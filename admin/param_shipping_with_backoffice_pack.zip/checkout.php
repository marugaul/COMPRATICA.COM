<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/shipping.php';

$pdo = db();
$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare("SELECT * FROM products WHERE id=? AND active=1");
$st->execute([$id]);
$p = $st->fetch(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Comprar - <?php echo APP_NAME; ?></title>
  <link rel="stylesheet" href="assets/style.css?v=16">
</head>
<body>
<header class="header">
  <div class="logo">🛒 <?php echo APP_NAME; ?></div>
  <nav><a class="btn" href="index.php">Volver</a></nav>
</header>

<div class="container">
  <?php if (!$p): ?>
    <div class="alert"><strong>Error:</strong> Producto no encontrado</div>
  <?php else: ?>
    <div class="card">
      <div class="imgbox">
        <img src="uploads/<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
      </div>
      <h2 style="margin:6px 0"><?= htmlspecialchars($p['name']) ?></h2>

      <?php if (!empty($p['description'])): ?>
        <div class="note" style="white-space:pre-wrap; margin-bottom:8px;">
          <?= nl2br(htmlspecialchars($p['description'])) ?>
        </div>
      <?php endif; ?>

      <div class="price">
        <?php if(($p['currency'] ?? 'CRC') === 'USD'): ?>
          $<?= number_format((float)$p['price'], 2, '.', ',') ?>
        <?php else: ?>
          ₡<?= number_format((float)$p['price'], 0, ',', '.') ?>
        <?php endif; ?>
        • Stock: <?= (int)$p['stock'] ?>
      </div>

      <?php if ((int)$p['stock'] <= 0): ?>
        <div class="alert">Agotado</div>
      <?php else: ?>
        <form class="form" method="post" action="buy.php">
          <input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>">

          <label>Cantidad
            <input class="input" type="number" name="qty" value="1" min="1" max="<?= (int)$p['stock'] ?>" required>
          </label>

          <label>Correo
            <input class="input" type="email" name="buyer_email" placeholder="tu@correo.com" required>
          </label>

          <label>Teléfono
            <input class="input" type="tel" name="buyer_phone" placeholder="8890 2814" required>
          </label>

          <label>Residencia
            <select class="input" name="residency" required>
              <option value="Monserrat">Monserrat</option>
              <option value="Concepcion">Concepcion</option>
              <option value="Otro">Otro</option>
            </select>
          </label>

          <div class="small" style="font-weight:600;margin-top:4px;">Envío</div>
          <label class="small" style="display:flex;gap:8px;align-items:center;">
            <input type="radio" name="shipping" value="pickup" checked>
            Recogerlo (₡0)
          </label>
          <label class="small" style="display:flex;gap:8px;align-items:center;">
            <input type="radio" name="shipping" value="delivery">
            Entrega dentro de Residencial Monserrat (₡<?= number_format(get_shipping_cost(), 0, ',', '.') ?>)
          </label>

          <label>Nota (opcional)
            <input class="input" type="text" name="note" placeholder="Instrucciones o comentario">
          </label>

          <button class="btn primary" type="submit">Confirmar compra</button>
        </form>
      <?php endif; ?>
    </div>
  <?php endif; ?>
</div>

<footer class="container small">© <?php echo date('Y'); ?> <?php echo APP_NAME; ?></footer>
</body>
</html>