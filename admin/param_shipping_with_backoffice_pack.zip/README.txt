VENTA GARAJE — Envío parametrizable (CRC)

Archivos incluidos:
- includes/shipping.php            -> Función get_shipping_cost() (lee/guarda en settings.shipping_cost_crc)
- checkout.php                     -> Muestra costo de entrega dinámico y la descripción del artículo
- buy.php                          -> Calcula subtotal + envío y muestra opciones de pago (SINPE + PayPal)
- admin/shipping_settings.php      -> Pantalla de Backoffice para editar el costo de envío
- tools/set_shipping_cost_once.php -> Utilidad para fijar el costo por URL y luego borrar

Cómo instalar
1) Suba el contenido del ZIP a su hosting, respetando carpetas.
2) (Opcional) Inicialice el costo por primera vez con una URL:
   https://SU_DOMINIO/tools/set_shipping_cost_once.php?v=2500
   Verá "OK: shipping_cost_crc = 2500". Luego borre ese archivo por seguridad.
3) Edite el costo cuando quiera desde Admin:
   https://SU_DOMINIO/admin/shipping_settings.php
   (Si su panel exige login, debe estar autenticado.)

Notas
- No se modificó la estructura de su base de datos de productos/pedidos.
- El costo de envío se guarda en la tabla settings (k='shipping_cost_crc').
- checkout.php y buy.php solo leen get_shipping_cost().
